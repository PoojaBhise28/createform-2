import UserModel from "./Model/UserModel";





// Validation function for first name
export const validateFirstName = (firstName: string): boolean => {
  // Example validation: Checking if first name is not empty and contains only letters
  return /^[a-zA-Z]+$/.test(firstName.trim());
};

// Validation function for last name
export const validateLastName = (lastName: string): boolean => {
  // Example validation: Checking if last name is not empty and contains only letters

  return /^[a-zA-Z]+$/.test(lastName.trim());
};

// Validation function for mobile number
export const validateMobileNumber = (mobileNumber: string): boolean => {
  // Example validation: Checking if mobile number is not empty and contains only digits
  return /^\d{10}$/.test(mobileNumber.trim());
};

// Validation function for phone number
export const validatePhoneNumber = (phoneNumber: string): boolean => {
  // Example validation: Checking if phone number is not empty and contains only digits
  return /^\d{10}$/.test(phoneNumber.trim());
};

// Validation function for description
export const validateDescription = (description: string): boolean => {
  // Example validation: Checking if description is not empty
  return description.trim() !== "";
};

// Validation function for the entire user model
export const validatePersonalInfo = (userData: UserModel): boolean => {
  // Example validation: You can implement more complex validations here
  return (
    validateFirstName(userData.firstName) &&
    validateLastName(userData.lastName) &&
    validateMobileNumber(userData.mobileNumber) &&
    validatePhoneNumber(userData.phoneNumber) &&
    validateDescription(userData.description)
  );
};


// export default function validatePersonalInfo(inputValues: UserModel): boolean {
//   var valid = true;

//   if (inputValues.firstName.length < 100) {
//     alert("firstname should be less tahn 100 charcter");
//     valid = false;
//   }
//   if (inputValues.lastName.length < 5) {
//     alert("lastName should be less tahn 100 charcter");
//     valid = false;
//   }
//   if (inputValues.mobileNumber.length !== 10) {
//     alert("mobileNumber should be 10 or 12 digit ");
//     valid = false;
//   }
//   if (inputValues.phoneNumber.length !== 10) {
//     alert("phoneNumber should be 10 or 12 digit ");
//     valid = false;
//   }
//   if (inputValues.description.length < 400) {
//     alert("description should be 10 or 12 digit ");
//     valid = false;
//   }
//   return valid;
// }
