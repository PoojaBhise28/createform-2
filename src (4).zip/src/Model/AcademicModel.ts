

 interface AcademicModel {

    Id:number;
    InstitutionName:string;
    StartYear:string;
    EndYear:string;
    Percentage:string;
    Degree:string;
    UserId:string;

}
export default  AcademicModel;
