interface EmployeModel {
    
      id:number;
      UserId:number
      NoticePeriod:number;
      ExpectedCTC:number
      CurrentCTC:number

      
    }
    
    export default EmployeModel;
   