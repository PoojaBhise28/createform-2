import React from 'react'

export default function EmploymentDetails() {
  return (
    <div>
      <h1>EmploymentDetailss</h1>
    </div>
  )
}
