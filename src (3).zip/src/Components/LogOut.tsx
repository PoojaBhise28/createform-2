import React from 'react'

export default function Logout() {
  return (
    <div>
        <h1>
        Logout
        </h1>
      
    </div>
  )
}
