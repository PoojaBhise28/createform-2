import PersonalInformation from "./Components/PersonalInfo";
import HomeRoute from "./routes/HomeRoute";



export default function App() {
  return (
    <>

     <HomeRoute/>

    
    </>
  );
}


      
       
     