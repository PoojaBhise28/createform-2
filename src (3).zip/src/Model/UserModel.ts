interface UserModel {
    emailAddress: string;
    password: string;
   
      firstName: string;
      lastName: string;
      mobileNumber:string;
     
      description:string;
     
      phoneNumber:string ;
      
      IsActive:boolean;
      userId:number;
      id:number;
      isUpdate:boolean;
    }
    
    export default UserModel;
 