import React from 'react'

export default function ExperienceDetails() {
  return (
    <div>
      <h1>ExperienceDetails</h1>
    </div>
  )
}
