import UserModel from "./Model/UserModel";

export default function validatePersonalInfo(inputValues: UserModel): boolean {
  var valid = true;

  if (inputValues.firstName.length < 100) {
    alert("firstname should be less tahn 100 charcter");
    valid = false;
  }
  if (inputValues.lastName.length < 5) {
    alert("lastName should be less tahn 100 charcter");
    valid = false;
  }
  if (inputValues.mobileNumber.length !== 10) {
    alert("mobileNumber should be 10 or 12 digit ");
    valid = false;
  }
  if (inputValues.phoneNumber.length !== 10) {
    alert("phoneNumber should be 10 or 12 digit ");
    valid = false;
  }
  if (inputValues.description.length < 400) {
    alert("description should be 10 or 12 digit ");
    valid = false;
  }
  return valid;
}
