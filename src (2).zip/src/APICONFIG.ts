const API_URL = "http://localhost:5203/api";
export { API_URL };
