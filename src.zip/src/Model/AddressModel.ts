interface AddressModel{
    Address:string;
    City:string
    StateId :string
    CountryId :number
}
export default AddressModel;